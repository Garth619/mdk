<?php
/**
 * Plugin Name: 1POINT21 SALES OUTREACH Gravity Form Entries via Post
 * Plugin URI: //1point21interactive.com
 * Description: Posts Gravity Form Entries to Sales Outreach Tool
 * Version: 1.0
 * Author: 1POINT21 Interactive
 */

add_action('gform_after_submission', 'post_to_sales_outreach', 10, 2);

function post_to_sales_outreach($entry, $form)
{

    wp_remote_post('https://enm68ib958uj3ju.m.pipedream.net', array(
        'method' => 'POST',
        'timeout' => 20,
        'headers' => array("Content-type" => "application/json", "GF_WEBHOOKS_KEY" => "418bca0d37ff498eb71be0f082b21710"),
        'body' => json_encode($entry),
    )
    );

}